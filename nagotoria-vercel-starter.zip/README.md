
# Nagotoria Vercel Starter

1. Установи [Node.js](https://nodejs.org/)
2. Установи зависимости:
   npm install
3. Запусти проект:
   npm run dev
4. Залей на [Vercel](https://vercel.com/import)

Структура:
- /public/videos — видеофайлы
- /public/art — арты
- /public/stories — книги и тексты

Приятного творчества!
    